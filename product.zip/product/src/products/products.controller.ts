import { Controller, Post, Body } from '@nestjs/common';

import { ProductsService } from './products.service';

@Controller('products')
export class ProductsController {
  constructor(private readonly ProductsService: ProductsService) {}

  @Post()
  addProduct(
    @Body('id') productId: number,
    @Body('barcode') productBarcode: string,
    @Body('qty') productQty: number,
    @Body('createdDate') productCreatedDate: Date,
    @Body('price') productPrice: number,
    @Body('state') productState: string,
  ) {
    const generatedId = this.ProductsService.insertProduct(
      productId,
      productBarcode,
      productQty,
      productCreatedDate,
      productPrice,
      productState,
    );
    return { id: generatedId };
  }
}

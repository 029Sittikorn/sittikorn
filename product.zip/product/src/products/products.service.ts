import { Injectable } from '@nestjs/common';

import { Product } from './product.model';

@Injectable()
export class ProductsService {
  products: Product[] = [];

  insertProduct(
    id: number,
    barcode: string,
    qty: number,
    createdDate: Date,
    price: number,
    state: string,
  ) {
    const newProduct = new Product(id, barcode, qty, createdDate, price, state);
    this.products.push(newProduct);
    return id;
  }
}

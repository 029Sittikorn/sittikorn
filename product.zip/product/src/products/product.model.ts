export class Product {
  constructor(
    public id: number,
    public barcode: string,
    public qty: number,
    public createdDate: Date,
    public price: number,
    public state: string,
  ) {}
}
